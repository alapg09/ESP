#ifndef LAYOUTS_H
#define LAYOUTS_H

void placeMines(int rows, int columns, char difficulty, char **grid);

#endif
