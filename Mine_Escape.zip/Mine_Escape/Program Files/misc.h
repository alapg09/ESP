#ifndef MISC_H
#define MISC_H
#include <string>

using namespace std;

char get_validated_input(const string &prompt, const string &validOptions); // modularizing repetitive input validations

#endif